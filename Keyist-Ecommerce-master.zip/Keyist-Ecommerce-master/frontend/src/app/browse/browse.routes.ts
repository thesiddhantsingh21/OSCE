import {BrowseComponent} from "./browse.component";
import {Routes} from "@angular/router";

export const BrowseRoutes: Routes = [
  {path: 'browse', component: BrowseComponent}
];
