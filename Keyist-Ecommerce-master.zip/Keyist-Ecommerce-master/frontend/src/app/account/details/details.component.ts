import {Component, OnInit} from '@angular/core';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/catch';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
