# E-commerce-Spring

### Technologies used: 
Spring Boot, Spring Security, Spring Data (Jpa Hibernate), MySql, Java, JavaScript, HTML, and CSS,

:point_down:Screenshot:

<img width="500" src="https://i.imgur.com/h8Ce9aw.jpg" >
