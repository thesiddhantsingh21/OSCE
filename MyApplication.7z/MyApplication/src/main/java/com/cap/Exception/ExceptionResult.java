package com.cap.Exception;

public class ExceptionResult {

}
