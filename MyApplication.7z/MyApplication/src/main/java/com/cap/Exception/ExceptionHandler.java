package com.cap.Exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice 
public class ExceptionHandler {

}
