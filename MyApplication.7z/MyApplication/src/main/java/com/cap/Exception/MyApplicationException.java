package com.cap.Exception;

public class MyApplicationException {

}
